import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BabyNames implements whatYaWannaGet {
	
	private String name;
	private String year;
	private String gender;
	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		BabyNames baby = new BabyNames();
		
		Scanner inputScan = new Scanner(System.in); //user input var
		List<String> queryList = new ArrayList<String>(); // options list
		queryList.add("Name");
		queryList.add("Year");
		queryList.add("Quit");
		String lineName; //keep track of name of baby of current line in file
		String lineGen; //keep track of gender of baby of current line in file
		double lineCount = 1; //keep track of current line in file
		int fileCount = 0; //keep track of current line in file
		double mostPopular = 0; // keep track of most popular name of year
		double prevMostPopular = 0; // keep track of most popular name of all years
		String mostPopularLine = null; // keep track of most popular name for year
		String prevMostPopularLine = null; //keep track of previous most popular line
		
		boolean moreQuery = true;
		while (moreQuery == true) { // add more to search if more query is true;
			System.out.println("what would you like to add to your search");
			for (String option : queryList) { //print things in list
				System.out.println(option);
			}
			String query = inputScan.nextLine();
			if (query.toUpperCase().equals("NAME")){
				queryList.remove("Name");
				System.out.println("enter a name"); //ask for name
				baby.setName(inputScan.nextLine()); //call setName method
				if (queryList.contains("Year")) { // check if year has been entered
					System.out.println("Enter Gender (M/F)"); // enter gender
					baby.setGender(inputScan.nextLine().toUpperCase()); // keep track of answer
					System.out.println("would you like to specify a year (yes or no)");
					if ((inputScan.nextLine().toUpperCase()).equals("NO")) {
						moreQuery = false;
					}
					else {
						query = "YEAR";
					}
				}
				else {
					moreQuery = false;
				}
			}
			if (query.toUpperCase().equals("YEAR")){
				System.out.println("enter a year (1880 - 2018)"); //ask for year
				baby.setYear(inputScan.nextLine()); //call setYear method
				queryList.remove("Year");
				if (queryList.contains("Name")) {
					System.out.println("Enter Gender (M/F)");
					baby.setGender(inputScan.nextLine().toUpperCase()); // keep track of answer
					System.out.println("would you like to specify a Name (yes or no)");
					if (inputScan.nextLine().toUpperCase().equals("NO")) {
						moreQuery = false;
					}
				}
				else {
					moreQuery = false;
				}
			}
			else if (query.toUpperCase().equals("QUIT")){
				baby.quit(); //stop code
			}
		} // end of while loop

		File dir = new File("ssa_complete");
		File[] directory = dir.listFiles();
		if(directory != null) {
			for (File file : directory) {
				if (fileCount > 0) {
					Scanner scanFile = new Scanner(file); //file scanner
					String line = "";
					lineCount = 1;
					while (scanFile.hasNextLine()) {
						line = scanFile.nextLine();
						lineName = line.substring(0,line.indexOf(","));
						lineGen = line.substring(line.indexOf(",")+1,line.indexOf(",")+2);
						if (queryList.contains("Year")) {
							if (lineName.toUpperCase().equals(baby.getName().toUpperCase()) && lineGen.toUpperCase().equals(baby.getGender().toUpperCase())){ //if name and gender
								mostPopular = lineCount;
								mostPopularLine = "" + (line + " year: " + (fileCount + 1879) + " rank: " + (lineCount));
								if (prevMostPopular == 0) {
									prevMostPopular = mostPopular;
								}
							}
						}
						
						else if (queryList.contains("Name")){
							if ((fileCount + 1879) == Integer.parseInt(baby.getYear()) && baby.getGender().toUpperCase().equals(lineGen.toUpperCase())) { // get most popular name for year
								if (lineCount == 1){
									System.out.println(lineName);
								break;
								}
						 	}
						}
						else if (!queryList.contains("Name") && (!queryList.contains("Year"))){
							if (lineName.toUpperCase().equals(baby.getName().toUpperCase()) && lineGen.toUpperCase().equals(baby.getGender().toUpperCase()) && (fileCount + 1879) == Integer.parseInt(baby.getYear())) { // get name rank for given year, name and gender
								System.out.println("" + line  + " year: " + (fileCount + 1879) + " rank: " + (lineCount));
							}
						}
						if (lineGen.toUpperCase().equals(baby.getGender().toUpperCase())) { // only add rank if gender is same
							lineCount ++;
						}
					}
					if (mostPopular/lineCount < prevMostPopular && queryList.contains("Year")) {
						prevMostPopular = mostPopular/lineCount;
						prevMostPopularLine = (mostPopularLine + " out of: " + lineCount);
						
					}
				}
				fileCount ++; // keep track of file count
			}
			if (queryList.contains("Year")) {
				System.out.println(prevMostPopularLine);
			}
		}
	}
	@Override
	public void setName(String newName) {
		name = newName;
	}
	@Override
	public String getName() {
		return name;
	}
	
	@Override
	public void setYear(String newYear) {
		// TODO Auto-generated method stub
		year = newYear;	
	}
	@Override
	public String getYear() {
		return year;
	}

	@Override
	public void setGender(String newGender) {
		// TODO Auto-generated method stub
		gender = newGender;
	}
	@Override
	public String getGender() {
		return gender;
	}
	
	public void quit() {
		System.out.println("bye bye");
		System.exit(0);
	
	}

}

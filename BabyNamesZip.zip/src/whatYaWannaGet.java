import java.util.ArrayList;

public interface whatYaWannaGet {
	
	
	String getName();
	String getYear();
	String getGender();
	void quit();
	void setName(String newName);
	void setYear(String newYear);
	void setGender(String newGender);
}
